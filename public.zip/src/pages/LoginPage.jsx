import React from "react";

const LoginPage = () => {
  return <div>Login page</div>;
};

export default LoginPage;
